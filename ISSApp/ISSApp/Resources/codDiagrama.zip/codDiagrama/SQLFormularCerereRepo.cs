
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public class SQLFormularCerereRepo : ISQLRepo {

    /**
     * 
     */
    public SQLFormularCerereRepo() {
    }

    /**
     * @param formular 
     * @return
     */
    public void add(FormularCerere formular) {
        // TODO implement here
        return null;
    }

    /**
     * @param formular 
     * @return
     */
    public FormularCerere delete(FormularCerere formular) {
        // TODO implement here
        return null;
    }

    /**
     * @param formular 
     * @return
     */
    public FormularCerere update(FormularCerere formular) {
        // TODO implement here
        return null;
    }

    /**
     * @param id 
     * @return
     */
    public FormularCerere findEntity(int id) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public List<FormularCerere> findAll() {
        // TODO implement here
        return null;
    }

}