
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public interface Persoana {

    /**
     * 
     */
    public string CNP;

    /**
     * 
     */
    public string Nume;

    /**
     * 
     */
    public string Prenume;

    /**
     * 
     */
    public date Dob;

    /**
     * 
     */
    public DateContact dateContact;

    /**
     * 
     */
    public Account account;



}