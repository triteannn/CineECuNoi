
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public class PSTrombocite : IProdusSanguin, IProdusSanguin, IProdusSanguin, IProdusSanguin, IProdusSanguin {

    /**
     * 
     */
    public PSTrombocite() {
    }

}