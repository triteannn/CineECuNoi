
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public interface ISQLRepo {

    /**
     * @param entity 
     * @return
     */
    public void add(T entity);

    /**
     * @param entity 
     * @return
     */
    public T delete(T entity);

    /**
     * @param entity 
     * @return
     */
    public T update(T entity);

    /**
     * @param id 
     * @return
     */
    public T findEntity(int id);

    /**
     * @return
     */
    public List<T> findAll();

}