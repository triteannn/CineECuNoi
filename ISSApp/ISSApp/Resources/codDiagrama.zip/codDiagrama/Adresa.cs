
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public class Adresa {

    /**
     * 
     */
    public Adresa() {
    }

    /**
     * 
     */
    public string Strada;

    /**
     * 
     */
    public int Numar;

    /**
     * 
     */
    public string Oras;

    /**
     * 
     */
    public string Judet;

}