
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public class Account {

    /**
     * 
     */
    public Account() {
    }

    /**
     * 
     */
    public string Username;

    /**
     * 
     */
    public string Password;

}