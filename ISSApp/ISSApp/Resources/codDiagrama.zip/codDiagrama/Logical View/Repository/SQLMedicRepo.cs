
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Repository{
    /**
     * 
     */
    public class SQLMedicRepo : ISQLRepo {

        /**
         * 
         */
        public SQLMedicRepo() {
        }



        /**
         * @param medic 
         * @return
         */
        public void add(Medic medic) {
            // TODO implement here
            return null;
        }

        /**
         * @param medic 
         * @return
         */
        public Medic delete(Medic medic) {
            // TODO implement here
            return null;
        }

        /**
         * @param medic 
         * @return
         */
        public Medic update(Medic medic) {
            // TODO implement here
            return null;
        }

        /**
         * @param id 
         * @return
         */
        public Medic findEntity(int id) {
            // TODO implement here
            return null;
        }

        /**
         * @return
         */
        public List<Medic> findAll() {
            // TODO implement here
            return null;
        }

    }
}