
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Repository{
    /**
     * 
     */
    public class SQLDonatorRepo : ISQLRepo {

        /**
         * 
         */
        public SQLDonatorRepo() {
        }



        /**
         * @param donator 
         * @return
         */
        public void add(Donator donator) {
            // TODO implement here
            return null;
        }

        /**
         * @param donator 
         * @return
         */
        public Donator delete(Donator donator) {
            // TODO implement here
            return null;
        }

        /**
         * @param donator 
         * @return
         */
        public Donator update(Donator donator) {
            // TODO implement here
            return null;
        }

        /**
         * @param id 
         * @return
         */
        public Donator findEntity(int id) {
            // TODO implement here
            return null;
        }

        /**
         * @return
         */
        public List<Donator> findAll() {
            // TODO implement here
            return null;
        }

    }
}