
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Repository{
    /**
     * 
     */
    public class SQLPlasmaRepo : ISQLRepo {

        /**
         * 
         */
        public SQLPlasmaRepo() {
        }


        /**
         * @param psPlasma 
         * @return
         */
        public void add(PSPlasma psPlasma) {
            // TODO implement here
            return null;
        }

        /**
         * @param psPlasma 
         * @return
         */
        public PSPlasma delete(PSPlasma psPlasma) {
            // TODO implement here
            return null;
        }

        /**
         * @param psPlasma 
         * @return
         */
        public PSPlasma update(PSPlasma psPlasma) {
            // TODO implement here
            return null;
        }

        /**
         * @param id 
         * @return
         */
        public PSPlasma findEntity(int id) {
            // TODO implement here
            return null;
        }

        /**
         * @return
         */
        public List<PSPlasma> findAll() {
            // TODO implement here
            return null;
        }

        /**
         * @param target 
         * @return
         */
        public List<PSPlasma> findByTarget(string target) {
            // TODO implement here
            return null;
        }

    }
}