
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Repository{
    /**
     * 
     */
    public class SQLAngajatRepo : ISQLRepo {

        /**
         * 
         */
        public SQLAngajatRepo() {
        }




        /**
         * @param angajatCentru 
         * @return
         */
        public void add(AngajatCentru angajatCentru) {
            // TODO implement here
            return null;
        }

        /**
         * @param angajatCentru 
         * @return
         */
        public AngajatCentru delete(AngajatCentru angajatCentru) {
            // TODO implement here
            return null;
        }

        /**
         * @param angajatCentru 
         * @return
         */
        public AngajatCentru update(AngajatCentru angajatCentru) {
            // TODO implement here
            return null;
        }

        /**
         * @param id 
         * @return
         */
        public AngajatCentru findEntity(int id) {
            // TODO implement here
            return null;
        }

        /**
         * @return
         */
        public List<AngajatCentru> findAll() {
            // TODO implement here
            return null;
        }

    }
}