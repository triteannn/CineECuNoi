
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Domain{
    /**
     * 
     */
    public class PSTrombocite : IProdusSanguin, IProdusSanguin, IProdusSanguin, IProdusSanguin, IProdusSanguin {

        /**
         * 
         */
        public PSTrombocite() {
        }

    }
}