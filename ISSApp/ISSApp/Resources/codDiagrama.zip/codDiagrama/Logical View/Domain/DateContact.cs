
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Domain{
    /**
     * 
     */
    public class DateContact {

        /**
         * 
         */
        public DateContact() {
        }

        /**
         * 
         */
        public string Telefon;

        /**
         * 
         */
        public string Email;

        /**
         * 
         */
        public Adresa adresa;



    }
}