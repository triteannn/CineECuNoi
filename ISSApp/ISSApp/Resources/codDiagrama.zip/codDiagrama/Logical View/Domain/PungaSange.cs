
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Domain{
    /**
     * 
     */
    public class PungaSange {

        /**
         * 
         */
        public PungaSange() {
        }

        /**
         * 
         */
        private date dataRecoltare;

        /**
         * 
         */
        private string grupa;

        /**
         * 
         */
        private string rh;

        /**
         * 
         */
        private string target;



    }
}