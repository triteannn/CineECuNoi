
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Domain{
    /**
     * 
     */
    public interface IPersoana {

        /**
         * 
         */
        public string CNP;

        /**
         * 
         */
        public string Nume;

        /**
         * 
         */
        public string Prenume;

        /**
         * 
         */
        public date Dob;

        /**
         * 
         */
        public DateContact dateContact;

        /**
         * 
         */
        public Account account;



    }
}