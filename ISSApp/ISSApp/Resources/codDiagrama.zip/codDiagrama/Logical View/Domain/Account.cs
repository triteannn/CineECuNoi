
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Domain{
    /**
     * 
     */
    public class Account {

        /**
         * 
         */
        public Account() {
        }

        /**
         * 
         */
        public string Username;

        /**
         * 
         */
        public string Password;

    }
}