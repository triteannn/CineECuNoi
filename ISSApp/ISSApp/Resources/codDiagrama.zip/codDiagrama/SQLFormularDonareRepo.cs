
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public class SQLFormularDonareRepo : ISQLRepo {

    /**
     * 
     */
    public SQLFormularDonareRepo() {
    }

    /**
     * @param formular 
     * @return
     */
    public void add(FormularDonare formular) {
        // TODO implement here
        return null;
    }

    /**
     * @param formular 
     * @return
     */
    public FormularDonare delete(FormularDonare formular) {
        // TODO implement here
        return null;
    }

    /**
     * @param formular 
     * @return
     */
    public FormularDonare update(FormularDonare formular) {
        // TODO implement here
        return null;
    }

    /**
     * @param id 
     * @return
     */
    public FormularDonare findEntity(int id) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public List<FormularDonare> findAll() {
        // TODO implement here
        return null;
    }

}