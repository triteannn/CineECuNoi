
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public class SQLTrombociteRepo : ISQLRepo {

    /**
     * 
     */
    public SQLTrombociteRepo() {
    }


    /**
     * @param psTrombocite 
     * @return
     */
    public void add(PSTrombocite psTrombocite) {
        // TODO implement here
        return null;
    }

    /**
     * @param psTrombocite 
     * @return
     */
    public PSTrombocite delete(PSTrombocite psTrombocite) {
        // TODO implement here
        return null;
    }

    /**
     * @param psTrombocite 
     * @return
     */
    public PSTrombocite update(PSTrombocite psTrombocite) {
        // TODO implement here
        return null;
    }

    /**
     * @param id 
     * @return
     */
    public PSTrombocite findEntity(int id) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public List<PSTrombocite> findAll() {
        // TODO implement here
        return null;
    }

    /**
     * @param target 
     * @return
     */
    public List<PSTrombocite> findByTarget(string target) {
        // TODO implement here
        return null;
    }

}