
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public class SQLProdSanguinRepo : ISQLRepo {

    /**
     * 
     */
    public SQLProdSanguinRepo() {
    }



    /**
     * @param ProdusSanguin produsSanguin 
     * @return
     */
    public void add(void ProdusSanguin produsSanguin) {
        // TODO implement here
        return null;
    }

    /**
     * @param ProdusSanguin produsSanguin 
     * @return
     */
    public IProdusSanguin delete(void ProdusSanguin produsSanguin) {
        // TODO implement here
        return null;
    }

    /**
     * @param ProdusSanguin newProdusSanguin 
     * @return
     */
    public IProdusSanguin update(void ProdusSanguin newProdusSanguin) {
        // TODO implement here
        return null;
    }

    /**
     * @param int id 
     * @param string typeProdusSanguin 
     * @return
     */
    public PSTrombocite findEntity(void int id, void string typeProdusSanguin) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public List<ProdusSanguin> findAll() {
        // TODO implement here
        return null;
    }

}