
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public class SQLGlobuleRosiiRepo : ISQLRepo {

    /**
     * 
     */
    public SQLGlobuleRosiiRepo() {
    }


    /**
     * @param psGlobuleRosii 
     * @return
     */
    public void add(PSGlobuleRosii psGlobuleRosii) {
        // TODO implement here
        return null;
    }

    /**
     * @param psGlobuleRosii 
     * @return
     */
    public PSGlobuleRosii delete(PSGlobuleRosii psGlobuleRosii) {
        // TODO implement here
        return null;
    }

    /**
     * @param psGlobuleRosii 
     * @return
     */
    public PSGlobuleRosii update(PSGlobuleRosii psGlobuleRosii) {
        // TODO implement here
        return null;
    }

    /**
     * @param id 
     * @return
     */
    public PSGlobuleRosii findEntity(int id) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public List<PSGlobuleRosii> findAll() {
        // TODO implement here
        return null;
    }

    /**
     * @param target 
     * @return
     */
    public List<PSGlobuleRosii> findByTarget(string target) {
        // TODO implement here
        return null;
    }

}