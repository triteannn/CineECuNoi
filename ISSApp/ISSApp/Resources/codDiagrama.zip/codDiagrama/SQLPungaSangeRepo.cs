
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public class SQLPungaSangeRepo : ISQLRepo {

    /**
     * 
     */
    public SQLPungaSangeRepo() {
    }



    /**
     * @param pungaSange 
     * @return
     */
    public void add(PungaSange pungaSange) {
        // TODO implement here
        return null;
    }

    /**
     * @param pungaSange 
     * @return
     */
    public PungaSange delete(PungaSange pungaSange) {
        // TODO implement here
        return null;
    }

    /**
     * @param pungaSange 
     * @return
     */
    public PungaSange update(PungaSange pungaSange) {
        // TODO implement here
        return null;
    }

    /**
     * @param id 
     * @return
     */
    public PungaSange findEntity(int id) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public List<PungaSange> findAll() {
        // TODO implement here
        return null;
    }

}